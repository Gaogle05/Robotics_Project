#!/usr/bin/env python
import numpy as np
import matplotlib.pyplot as plt
import random
from PIL import Image, ImageOps  # Python pillow

# Function converts the image into a numpy array of 0s and 1s
def convert_image(show):
    # NOTE: the grid is (y,x) not (x,y)
    img = Image.open('new_map.png')
    img = ImageOps.grayscale(img)
    np_img = np.array(img)
    np_img = ~np_img  # inverts black and white
    np_img[np_img > 0] = 1
    plt.set_cmap('binary')
    plt.imshow(np_img)
    np.save('map.npy', np_img)
    grid = np.load('map.npy')
    plt.imshow(grid)
    plt.tight_layout()
    if (show == 1):
        plt.show()
convert_image(1)
print("done")