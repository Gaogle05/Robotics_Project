# RRT Algo
# Salmaan
import numpy as np
import matplotlib.pyplot as plt
import random
from PIL import Image, ImageOps  # Python pillow

from pid_controller import PID
from gazebo_msgs.srv import GetModelState
from geometry_msgs.msg import Twist, Point
import rospy

from rrt_class import RRTAlgorithm

# instance of the class
def RRT(values, printer):
    start, goal, numIterations, grid, stepSize = values
    rrt = RRTAlgorithm(start, goal, numIterations, grid, stepSize)

    for i in range(rrt.iterations):
        # Reset nearest values
        rrt.resetNearestValues()
        # print("iteration: ", i)

        # algo
        point = rrt.sampleAPoint()
        rrt.findNearest(rrt.randomTree, point)
        new = rrt.steerToPoint(rrt.nearestNode, point)
        boolObstacle = rrt.isInObstacle(rrt.nearestNode, new)
        if (boolObstacle == False):
            rrt.addChild(new[0], new[1])
            # plt.pause(0.10)
            # plt.plot([rrt.nearestNode.locationX, new[0]], [rrt.nearestNode.locationY, new[1]], 'go', linestyle="--")
            plt.plot([rrt.nearestNode.locationX, new[0]], [
                     rrt.nearestNode.locationY, new[1]], 'go', linestyle="--")
            # if goal found, append to path
            if (rrt.goalFound(new)):
                rrt.addChild(goal[0], goal[1])
                #print("Goal found!")
                break

    # trace back the path returned then adds start to waypoints
    rrt.retraceRRTPath(rrt.goal)
    rrt.Waypoints.insert(0, start)

    if (printer):
        print("Iterations: ", rrt.iterations)
        print("Num Waypoints", rrt.numWaypoints)
        print("Path distance (m): ", rrt.path_distance)
        #print("Waypoints: ", rrt.Waypoints)

    return rrt.Waypoints

# Function converts the image into a numpy array of 0s and 1s
def convert_image(show):
    # NOTE: the grid is (y,x) not (x,y)
    img = Image.open('C:/Users/salma/Desktop/MrRobot/Algo/map.png')
    img = ImageOps.grayscale(img)
    np_img = np.array(img)
    np_img = ~np_img  # inverts black and white
    np_img[np_img > 0] = 1
    plt.set_cmap('binary')
    plt.imshow(np_img)
    np.save('map.npy', np_img)
    grid = np.load('map.npy')
    plt.imshow(grid)
    plt.tight_layout()
    if (show == 1):
        plt.show()

#plotting start and goal for RRT
def plotStartGoal(values):
    start, goal, numIterations, grid, stepSize = values

    goalRegion = plt.Circle(
        (goal[0], goal[1]), stepSize, color='b', fill=False)
    fig = plt.figure("RRT Algo")
    # plotting
    plt.imshow(grid, cmap='binary')
    plt.plot(start[0], start[1], 'ro')
    plt.plot(goal[0], goal[1], 'bo')
    ax = fig.gca()
    ax.add_patch(goalRegion)
    plt.xlabel('X-axis $(m)$')
    plt.ylabel('Y-xis $(m)$')
    plt.title('RRT Algo by MrRobot')
    # plt.show()

#plotting red points for RRT
def plotWaypoints(Waypoints):
    for i in range(len(Waypoints)-1):
        plt.plot([Waypoints[i][0], Waypoints[i+1][0]],
                 [Waypoints[i][1], Waypoints[i+1][1]],
                 'ro', linestyle="--")
        plt.pause(0.10)

#shows plot
def plotRRT(Waypoints):
    # plotStartGoal(values)
    plotWaypoints(Waypoints)
    plt.show()

#get inital values
def getValues(s_x, s_y, g_x, g_y):
    grid = np.load('map.npy')
    start = np.array([s_x+0.0, s_y+0.0])
    goal = np.array([g_x+0.0, g_y+0.0])
    numIterations = 500
    stepSize = 25
    return [start, goal, numIterations, grid, stepSize]

#printing co-ords
def printArray(arr, n):
    for i in range(n):
        #print("x: ", round(arr[i][0], 2), "\t y :", round(arr[i][1], 2))
        print('x: {:0.2f}.'.format(arr[i][0]), 'y: {:0.2f}.'.format(arr[i][1]))

#mapping co-ords from image to gazebo map for entire array
def arr_coords_plt_to_map(path):
    # change to map coords as array
    print("entered change")
    for i in range(path.shape[0]):
        path[i][0], path[i][1] = coords_plt_to_map(float(format(path[i][0], ".2f")),float(format(path[i][1], ".2f"))) #round(path[i][1],2))
    #print("path is", path)
    return path

#function to swap x and y that resembles a rotation
def swap_cols(arr):
    for a in arr:
        t = a[0]
        a[0] = a[1]
        a[1] = t
    return arr

#gets inital values, runs RRT algorithm, plots waypoints, and assesses if the algorithm is good or should be recalculated
def to_main(startx, starty, goalx, goaly):
    # convert_image(1)  # 0 to leave map, 1 to show it
    s_x, s_y, g_x, g_y = startx, starty, goalx, goaly
    values = getValues(s_x, s_y, g_x, g_y)

    plotStartGoal(values)
    recalculations = 0  # sometimes it doesn't find the goal
    #To-do optimise using RRT* or RRT#
    num_waypoints = 2
    recalculated_too_many_times = False
    while num_waypoints == 2:  # while loop becomes sometimes RRTs random nodes doesn't reach the goal node
        # 1 means print details, 0 means leave it out
        Waypoints = RRT(values, 0)
        #plotRRT(values, Waypoints)
        # print(Waypoints)
        num_waypoints = len(Waypoints)
        #print("Number of waypoints: ", num_waypoints)
        if (num_waypoints > 2):
            plotWaypoints(Waypoints)
            plt.show()
            #printArray(Waypoints, num_waypoints)
        else:
            #print("Recalculating...")
            recalculations += 1
            if recalculations > 25:
                recalculated_too_many_times = True
                break
    if (recalculated_too_many_times):
        print('Out of map error: select co-ordinates in the range Sir')
    print('Goal found!')
    print('Number of waypoints: ', num_waypoints)
    #print("Times recalculated: ", recalculations)
    #print("End of file")
    return Waypoints

#mapping co-ords from image array to gazebo co-ords
def coordTransform_MapToGaz(arr):
    for a in arr:
        #a[0] = round((-a[0]+325)/25,2)
        #a[1] = round((-a[1]+175)/25,2) #- or +, try both
        a[0] = round((-a[0]+325)/25,2)
        a[1] = round((-a[1]+175)/25,2)
    return arr

#mapping co-ords from gazebo co-ords to image array
def coordTransform_GazToMap(a):
    a[0] = 325-a[0]*25
    a[1] = 175-a[1]*25
    return a

#main function that returns "path"
def main():

    pid = PID()
    state = pid.get_state()
    startx = state.pose.position.x
    starty = state.pose.position.y

    #print("Start pos: ", startx, starty)
    print("\nHello Mr. Top Secret Government Agent - i.e. Pravesh/Benji :)\nInstruct me on where to go in (x,y) co-ordinates.\n")

    goalx = 1*float(input('x (goal): '))
    goaly = 1*float(input('y (goal): '))
    
    x_max = 16 - startx
    y_max = 20 - starty

    x_min = -(16 - startx)
    y_min = -(20 - starty)

    #checks boundaries: x in [0,16] and y in [0,20]
    while (goalx >= x_max or goaly >= y_max or goalx <= x_min or goaly <= y_min):
        print("\nSir, I am unauthorised to access that location. Please provide me with new (x,y) co-ords.\n")
        goalx = float(input('x1 (goal): '))
        goaly = float(input('x2 (goal): '))
        
    print("\nMission Accepted Sir.\nI am just calculating the path, then we're ready to go!\nI will look for suspicious objects on my way there.\nPath: calculating...\n")


    s_x, s_y = coordTransform_GazToMap([startx, starty])
    g_x, g_y = coordTransform_GazToMap([goalx, goaly])
    
    #print(s_x, s_y, g_x, g_y)

    waypoints = to_main(s_x, s_y, g_x, g_y)

    gaz_waypoints = coordTransform_MapToGaz(waypoints)
    transposed_path = swap_cols(gaz_waypoints)

    print("Gazebo coords: ")
    printArray(transposed_path, len(transposed_path))
    return transposed_path

#return to MrRobot.py
path = main()


