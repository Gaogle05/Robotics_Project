#!/usr/bin/env python
import rospy
from geometry_msgs.msg import Twist
from std_msgs.msg import String
from turtlesim.msg import Pose
from math import pow, atan2, sqrt
from gazebo_msgs.msg import ModelStates
from tf.transformations import euler_from_quaternion
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
import cv2

import numpy as np

rospy.init_node('opencv_example', anonymous=True)
bridge = CvBridge()

#detects utility Cart
def image_callback(img_msg):
    pub = rospy.Publisher('/witsdetector', String, queue_size=10)
    try:
        cv_image = bridge.imgmsg_to_cv2(img_msg, "bgr8")# read in the image from ros to convert to a opencv image
    except CvBridgeError, e:
        rospy.logerr("CvBridge Error: {0}".format(e))

    hsv = cv2.cvtColor(cv_image, cv2.COLOR_BGR2HSV)  # convert to hsv
    green = np.uint8([[[5, 5, 255]]]) #gets green of the utility bot
    hsvGreen = cv2.cvtColor(green, cv2.COLOR_BGR2HSV)
    
    ming = hsvGreen[0][0][0]-1, 100, 100 # determine its ower bound for detecting the utility bot
    maxg = hsvGreen[0][0][0]+1, 255, 255 # determine its upper bound for detecting the utility bot
    mask_g = cv2.inRange(hsv, ming, maxg) # create a mask to isolate the green in that range

    # if the mask does not contain isolations of that colour i.e. all numbers in mask are 0 (black):
    if (np.all((mask_g == 0))):
        pub.publish("No") #no utility cart in view
    else:
        pub.publish("Yes") #the cart contains isolations of that colour

global sub_once
sub_once = rospy.Subscriber("/camera/rgb/image_raw", Image, image_callback)
while not rospy.is_shutdown():
    rospy.spin()
    break
